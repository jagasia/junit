package test;

public interface User {

}
