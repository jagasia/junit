package test;

public interface Admin {

}
