package my_group_1.my_test_app_1;

public class Maths {
	public int sum(int i, int j)
	{
		return i+j;
	}

	public int product(int i, int j)
	{
		return i*j;
	}
}
