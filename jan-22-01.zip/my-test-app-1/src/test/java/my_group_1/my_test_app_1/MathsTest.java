package my_group_1.my_test_app_1;

import junit.framework.TestCase;

public class MathsTest extends TestCase{
	Maths aut=new Maths();
	 public void testSum1()
	    {
	    	int result = aut.sum(2, 3);
	    	assertEquals(15, result);
	    }
}
