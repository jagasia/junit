package test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.Timeout;

import model.Maths;

public class MathsSumTest {
	
	@Rule
	public Timeout globalTimeOut=new Timeout(3000);
	
	@Rule
	public ExpectedException exception=ExpectedException.none();
	
	@Test
	public void exceptionBlock()
	{
//		exception.expect(ArithmeticException.class);
//		exception.expectMessage("error");
		System.out.println("error occurred");
	}
	static Maths aut=new Maths();
	@BeforeClass
	public static void setup()
	{
		System.out.println("before is executed");
		aut.no1=25;
		aut.no2=0;
	}
	
	@Test 
	public void testSum1()
	{
		assertEquals("they are not equal",155, aut.sum());
	}
	@Test 
	public void testSum2() throws InterruptedException
	{
		Thread.sleep(3000);
		assertEquals(15, aut.sum());
	}	
	@Test(expected = MyException.class)
	@Ignore
	public void testDivide()
	{
		float result=aut.divide();
		assertEquals(100, result);
	}
	@After
	public void teardown()
	{
		System.out.println("Testing is complete");
	}
}
