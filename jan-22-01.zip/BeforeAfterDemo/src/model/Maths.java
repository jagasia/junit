package model;

import test.MyException;

public class Maths {
	public int no1;
	public int no2;
	
	public int sum()
	{
		return no1+no2;
	}
	
	public int product()
	{
		return no1+no2;
	}
	public float divide()
	{
		throw new MyException("Jag raised an unchecked exception ");
	}
}
