package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import model.Maths;

public class MathsTest {
	Maths m=new Maths();
		@Before 
	public void setup()
	{
			m.i=2;
			m.j=3;
	}

		@Test
		public void testSum()
		{
			assertEquals(55, m.sum());
		}
}
