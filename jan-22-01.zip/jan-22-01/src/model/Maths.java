package model;

import org.junit.Before;

public class Maths {
	public int i,j;
	public int sum()
	{
		return i+j;
	}

	public int product()
	{
		return i*j;
	}
}
